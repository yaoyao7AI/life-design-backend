import { Router } from "express";
import { pool } from "../db.js";
import { authenticateToken } from "../middleware/auth.js";
import {
  normalizeElementForPersistence,
  normalizeElementForResponse,
} from "./vision-element-normalizers.js";
import { normalizeUploadsUrl } from "../utils/publicUploadUrl.js";

const router = Router();

function hasOwn(obj, key) {
  return Object.prototype.hasOwnProperty.call(obj, key);
}

function getCompatField(body, primaryKey, legacyKey) {
  if (hasOwn(body, primaryKey)) return body[primaryKey];
  if (hasOwn(body, legacyKey)) return body[legacyKey];
  return undefined;
}

function getCompatFieldFromKeys(body, keys) {
  for (const key of keys) {
    if (hasOwn(body, key)) return body[key];
  }
  return undefined;
}

let visionElementColumnSetPromise;
let visionBoardColumnSetPromise;

async function getVisionElementColumnSet() {
  if (!visionElementColumnSetPromise) {
    visionElementColumnSetPromise = pool
      .query(
        `SELECT COLUMN_NAME
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = 'vision_elements'`
      )
      .then(([rows]) => new Set(rows.map((row) => row.COLUMN_NAME)))
      .catch((err) => {
        console.warn("[vision_elements字段探测失败，回退基础字段]", err?.message || err);
        return new Set();
      });
  }

  return visionElementColumnSetPromise;
}

async function getVisionBoardColumnSet() {
  if (!visionBoardColumnSetPromise) {
    visionBoardColumnSetPromise = pool
      .query(
        `SELECT COLUMN_NAME
         FROM INFORMATION_SCHEMA.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = 'vision_boards'`
      )
      .then(async ([rows]) => {
        const columnSet = new Set(rows.map((row) => row.COLUMN_NAME));

        // 自动补齐历史库缺失字段，确保详情接口可回传 background_color
        if (!columnSet.has("background_color")) {
          try {
            await pool.query(
              "ALTER TABLE vision_boards ADD COLUMN background_color VARCHAR(32) NULL AFTER thumbnail"
            );
            columnSet.add("background_color");
          } catch (alterErr) {
            const message = String(alterErr?.message || alterErr || "");
            const duplicatedColumn =
              message.includes("Duplicate column name") || alterErr?.code === "ER_DUP_FIELDNAME";
            if (duplicatedColumn) {
              columnSet.add("background_color");
            } else {
              console.warn(
                "[vision_boards自动补齐background_color失败]",
                alterErr?.message || alterErr
              );
            }
          }
        }

        return columnSet;
      })
      .catch((err) => {
        console.warn("[vision_boards字段探测失败，回退基础字段]", err?.message || err);
        return new Set();
      });
  }

  return visionBoardColumnSetPromise;
}

function formatBoard(board) {
  const title = board?.title ?? board?.name ?? null;
  const coverUrl = board?.cover_url ?? board?.thumbnail ?? null;
  const backgroundColor =
    board?.background_color ?? board?.backgroundColor ?? board?.bg_color ?? null;

  return {
    ...board,
    title,
    cover_url: coverUrl,
    background_color: backgroundColor,
    // 兼容期保留历史字段，确保新旧前端都可读
    name: board?.name ?? title,
    thumbnail: board?.thumbnail ?? coverUrl,
  };
}

// 所有路由都需要认证
router.use(authenticateToken);

/**
 * 获取我的愿景板列表
 * GET /api/vision
 */
router.get("/", async (req, res) => {
  try {
    const userId = req.userId;
    const boardColumnSet = await getVisionBoardColumnSet();
    const hasBackgroundColorColumn = boardColumnSet.has("background_color");
    const backgroundSelect = hasBackgroundColorColumn ? ", background_color" : "";

    const [rows] = await pool.query(
      `SELECT id, user_id, name, quadrant, thumbnail, created_at${backgroundSelect}
       FROM vision_boards
       WHERE user_id = ?
       ORDER BY created_at DESC`,
      [userId]
    );

    res.json({ success: true, data: rows.map(formatBoard) });
  } catch (err) {
    console.error("[获取愿景板列表错误]", err);
    res.status(500).json({ error: "获取愿景板列表失败" });
  }
});

/**
 * 获取单个愿景板详情（包含元素）
 * GET /api/vision/:id
 */
router.get("/:id", async (req, res) => {
  try {
    const userId = req.userId;
    const { id } = req.params;

    // 获取愿景板信息
    const [boards] = await pool.query(
      "SELECT * FROM vision_boards WHERE id = ? AND user_id = ?",
      [id, userId]
    );

    if (boards.length === 0) {
      return res.status(404).json({ error: "愿景板不存在" });
    }

    // 获取愿景板元素
    const columnSet = await getVisionElementColumnSet();
    const hasScaleColumn = columnSet.has("scale");
    const selectScale = hasScaleColumn ? ", scale" : "";
    const [elements] = await pool.query(
      `SELECT id, type, content, x, y, width, height, rotation, font_size, color${selectScale}
       FROM vision_elements
       WHERE board_id = ?
       ORDER BY id ASC`,
      [id]
    );

    const board = formatBoard(boards[0]);

    res.json({
      success: true,
      data: {
        ...board,
        elements: elements.map(normalizeElementForResponse)
      }
    });
  } catch (err) {
    console.error("[获取愿景板详情错误]", err);
    res.status(500).json({ error: "获取愿景板详情失败" });
  }
});

/**
 * 创建新愿景板
 * POST /api/vision
 */
router.post("/", async (req, res) => {
  try {
    const userId = req.userId;
    const titleOrName = getCompatField(req.body, "title", "name");
    const coverOrThumbnail = normalizeUploadsUrl(
      getCompatField(req.body, "cover_url", "thumbnail")
    );
    const backgroundColor = getCompatFieldFromKeys(req.body, [
      "background_color",
      "backgroundColor",
      "bg_color",
    ]);
    const { quadrant } = req.body;
    const boardColumnSet = await getVisionBoardColumnSet();
    const hasBackgroundColorColumn = boardColumnSet.has("background_color");

    const insertColumns = ["user_id", "name", "quadrant", "thumbnail"];
    const insertValues = [
      userId,
      titleOrName ?? null,
      quadrant ?? null,
      coverOrThumbnail ?? null,
    ];
    if (hasBackgroundColorColumn) {
      insertColumns.push("background_color");
      insertValues.push(backgroundColor ?? null);
    }

    const [result] = await pool.query(
      `INSERT INTO vision_boards (${insertColumns.join(", ")})
       VALUES (${insertColumns.map(() => "?").join(", ")})`,
      insertValues
    );

    const boardId = result.insertId;
    const [boards] = await pool.query(
      "SELECT * FROM vision_boards WHERE id = ? AND user_id = ?",
      [boardId, userId]
    );
    const board = formatBoard(boards[0] || {
      id: boardId,
      user_id: userId,
      name: titleOrName ?? null,
      quadrant: quadrant ?? null,
      thumbnail: coverOrThumbnail ?? null,
      background_color: backgroundColor ?? null,
    });

    res.json({
      success: true,
      data: board
    });
  } catch (err) {
    console.error("[创建愿景板错误]", err);
    res.status(500).json({ error: "创建愿景板失败" });
  }
});

/**
 * 更新愿景板
 * PUT /api/vision/:id
 */
router.put("/:id", async (req, res) => {
  try {
    const userId = req.userId;
    const { id } = req.params;
    const titleOrName = getCompatField(req.body, "title", "name");
    const coverOrThumbnail = normalizeUploadsUrl(
      getCompatField(req.body, "cover_url", "thumbnail")
    );
    const backgroundColor = getCompatFieldFromKeys(req.body, [
      "background_color",
      "backgroundColor",
      "bg_color",
    ]);
    const hasQuadrant = hasOwn(req.body, "quadrant");
    const hasBackgroundColor = ["background_color", "backgroundColor", "bg_color"].some(
      (key) => hasOwn(req.body, key)
    );
    const boardColumnSet = await getVisionBoardColumnSet();
    const hasBackgroundColorColumn = boardColumnSet.has("background_color");

    // 验证所有权
    const [boards] = await pool.query(
      "SELECT id FROM vision_boards WHERE id = ? AND user_id = ?",
      [id, userId]
    );

    if (boards.length === 0) {
      return res.status(404).json({ error: "愿景板不存在" });
    }

    const setClauses = [];
    const values = [];

    if (titleOrName !== undefined) {
      setClauses.push("name = ?");
      values.push(titleOrName ?? null);
    }
    if (hasQuadrant) {
      setClauses.push("quadrant = ?");
      values.push(req.body.quadrant ?? null);
    }
    if (coverOrThumbnail !== undefined) {
      setClauses.push("thumbnail = ?");
      values.push(coverOrThumbnail ?? null);
    }
    if (hasBackgroundColor && hasBackgroundColorColumn) {
      setClauses.push("background_color = ?");
      values.push(backgroundColor ?? null);
    }

    if (setClauses.length === 0) {
      return res.status(400).json({
        error:
          "至少提供一个可更新字段：title/name、cover_url/thumbnail、quadrant、background_color",
      });
    }

    values.push(id);

    // 仅更新请求中携带的字段，避免未传字段被置空
    await pool.query(
      `UPDATE vision_boards SET ${setClauses.join(", ")} WHERE id = ?`,
      values
    );

    const [updatedBoards] = await pool.query(
      "SELECT * FROM vision_boards WHERE id = ? AND user_id = ?",
      [id, userId]
    );

    res.json({
      success: true,
      message: "更新成功",
      data: formatBoard(updatedBoards[0]),
    });
  } catch (err) {
    console.error("[更新愿景板错误]", err);
    res.status(500).json({ error: "更新愿景板失败" });
  }
});

/**
 * 删除愿景板
 * DELETE /api/vision/:id
 */
router.delete("/:id", async (req, res) => {
  try {
    const userId = req.userId;
    const { id } = req.params;

    // 验证所有权
    const [boards] = await pool.query(
      "SELECT id FROM vision_boards WHERE id = ? AND user_id = ?",
      [id, userId]
    );

    if (boards.length === 0) {
      return res.status(404).json({ error: "愿景板不存在" });
    }

    // 删除元素（外键约束会自动处理，但显式删除更清晰）
    await pool.query("DELETE FROM vision_elements WHERE board_id = ?", [id]);

    // 删除愿景板
    await pool.query("DELETE FROM vision_boards WHERE id = ?", [id]);

    res.json({ success: true, message: "删除成功" });
  } catch (err) {
    console.error("[删除愿景板错误]", err);
    res.status(500).json({ error: "删除愿景板失败" });
  }
});

/**
 * 保存愿景板元素
 * POST /api/vision/:id/elements
 */
router.post("/:id/elements", async (req, res) => {
  try {
    const userId = req.userId;
    const { id } = req.params;
    const { elements } = req.body; // elements 是数组

    // 验证愿景板所有权
    const [boards] = await pool.query(
      "SELECT id FROM vision_boards WHERE id = ? AND user_id = ?",
      [id, userId]
    );

    if (boards.length === 0) {
      return res.status(404).json({ error: "愿景板不存在" });
    }

    // 删除旧元素
    await pool.query("DELETE FROM vision_elements WHERE board_id = ?", [id]);

    const columnSet = await getVisionElementColumnSet();
    const hasScaleColumn = columnSet.has("scale");

    // 插入新元素
    if (elements && elements.length > 0) {
      const normalizedElements = elements.map(normalizeElementForPersistence);
      const values = normalizedElements.map((el) => {
        const row = [
          id,
          el.type,
          el.content,
          el.x,
          el.y,
          el.width,
          el.height,
          el.rotation,
          el.font_size,
          el.color,
        ];

        if (hasScaleColumn) {
          row.push(el.scale);
        }

        return row;
      });

      const placeholderItem = hasScaleColumn
        ? "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        : "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      const placeholders = values.map(() => placeholderItem).join(",");
      const flatValues = values.flat();
      const insertScale = hasScaleColumn ? ", scale" : "";

      await pool.query(
        `INSERT INTO vision_elements 
         (board_id, type, content, x, y, width, height, rotation, font_size, color${insertScale})
         VALUES ${placeholders}`,
        flatValues
      );
    }

    res.json({ success: true, message: "保存成功" });
  } catch (err) {
    console.error("[保存愿景板元素错误]", err);
    res.status(500).json({ error: "保存失败" });
  }
});

export default router;
